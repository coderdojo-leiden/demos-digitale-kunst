function maakDemo()
{ 

// --------- HIER BEGINT JE DEMO --------------


laag(Achtergrond)

laag(Tekst)


// laag(Vorm)
// wijzig("vorm", vorm.ster())
// wijzig("kleur", "zwart")
// laag(Draai)
// wijzig("hoek", getal.teller(20, 0, 360))

// laag(Tekst)
// wijzig("kleur", "blauw")
// wijzig("tekst", "Coding is cool!")
// wijzig("lettertype", "oud")


// const v = [
//     "cartoon",
//     "boek",
//     "handschrift",
//     "computer",
//     "krant",
//     "oud",
//     "wildwest"
// ];
// for (let i = 0; i < v.length; i++) {
//     laag(Tekst)
//     wijzig("kleur", "zwart")
//     wijzig("tekst", v[i])
//     wijzig("lettertype", v[i])
//     laag(Grootte)
//     wijzig("grootte", 50)
//     laag(Verplaats)
//     wijzig("pad", pad.omlaag(i * 50 - 300))
// }


// laag(Cirkels)
// wijzig("kleur", "groen")
// wijzig("dikte", 3)
// wijzig("afstand", 30)
// laag(Cirkels)
// wijzig("kleur", "groen")
// wijzig("dikte", 3)
// wijzig("afstand", 30)
// laag(Verplaats)
// wijzig("pad", pad.rechts(getal.golf()))

// laag(Vorm)
// wijzig("vorm", vorm.hart())
// wijzig("kleur", kleur.regenboog())
// laag(Grootte)
// wijzig("grootte", getal.golf(30, 50, 150))
// laag(Vermenigvuldig)
// wijzig("variatie", 30)
// wijzig("aantal", 10)
// wijzig("afstand", getal.golf(10, 150, 250))
// laag(Draai)
// wijzig("hoek", getal.teller(100, 0, 360))
// laag(Grootte)
// wijzig("grootte", getal.golf(10, 90, 110))

// laag(Tekst)
// wijzig("tekst", "Coding is cool!")
// laag(Verplaats)
// wijzig("pad", pad.omhoog(250))
// laag(Draai)
// wijzig("hoek", getal.golf(20, 50))
// laag(Grootte)
// wijzig("grootte", 120)

//muziek('Uj8MsbgpjaQ')


// --------- HIER EINDIGT JE DEMO --------------

}
