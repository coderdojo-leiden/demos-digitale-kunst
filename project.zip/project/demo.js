function maakDemo()
{ 

// --------- HIER BEGINT JE DEMO --------------


laag(Achtergrond)

laag(Tekst)


// --------- HIER EINDIGT JE DEMO --------------

}
